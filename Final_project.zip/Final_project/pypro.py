from tkinter import  * 
from tkinter.messagebox import *
from sqlite3 import *
from tkinter.font import Font
from tkinter.scrolledtext import *
import matplotlib.pyplot as plt
import requests 
import bs4




def f(num):
	if num == 1:
		add_window.deiconify()
		window .withdraw()
		add_window_ent_rno.delete(0,END)
		add_window_ent_name.delete(0,END)
		add_window_ent_marks.delete(0,END)
	elif num == 2:
		window.deiconify()
		add_window.withdraw()
		add_window_ent_rno.delete(0,END)
		add_window_ent_name.delete(0,END)
		add_window_ent_marks.delete(0,END)
	elif num == 3:
		con = None
		try:
			con = connect('Tejas.db')
			cursor = con.cursor()
			sql = "insert into student values(?,?,?)"
			rno = int(add_window_ent_rno.get())
			name = add_window_ent_name.get()
			marks =int(add_window_ent_marks.get())
			para = (rno,name,marks)
			cursor.execute(sql ,para)
			if  rno == "":
				showwarning('Fill Roll Number Section','Roll No. should only be empty and Roll No. should not be integers')
				con.rollback()
				add_window_ent_rno.delete(0,END)
				add_window_ent_rno.focus()

			elif rno <= 0 or len(str(rno)) > 4 : 
				showwarning('Wrong input','Enter positive numbers only and length of rno should not be more than 4 also it should not be empty')
				con.rollback()
				add_window_ent_rno.delete(0,END)
				add_window_ent_rno.focus()	 
			
			elif name == "" :
				showwarning('Wrong input','Name should not be empty')
				con.rollback()
				add_window_ent_name.delete(0,END)
				add_window_ent_name.focus()  
			
			elif len(name) < 2 or name.isalpha() == False:
				showwarning('Wrong input','Name should only have alphabets and the length of name should not be less than 2')
				con.rollback()
				add_window_ent_name.delete(0,END)
				add_window_ent_name.focus()
				
			elif  marks == "" or marks > 100 or marks < 0:
				showwarning('Wrong input','Marks should be in the range of 0 to 100 and it should not be empty')
				con.rollback()
				add_window_ent_marks.delete(0,END)
				add_window_ent_marks.focus()
				
			else:
				con.commit()
				showinfo('Success','Record Created')
				add_window_ent_rno.delete(0,END)
				add_window_ent_name.delete(0,END)
				add_window_ent_marks.delete(0,END)
				add_window_ent_rno.focus()
		
		except ValueError:
			d = "Enter Integer Values"
			showwarning('Failure',d)
			add_window_ent_rno.delete(0,END)
			add_window_ent_marks.delete(0,END)
			con.rollback()

		except Exception as e:
			showerror('Issue',e)
			con.rollback()
		finally:
			if con is not None:
				con.close()

		
		

		
	elif num == 4:
		view_window.withdraw()
		window.deiconify()
	elif num == 5:
		window.withdraw()
		view_window.deiconify()
		view_window_st_data.delete(1.0,END)
		info = ""
		con = None
		try:
			con = connect('Tejas.db')
			cursor = con.cursor()
			sql = "select * from student"
			cursor.execute(sql)
			data = cursor.fetchall()
			for d in data:
				info = info + " rno = " + str(d[0]) + '\t' + " name = " + str(d[1]) + '\t' + " marks = " + str(d[2]) + '\t' + '\n\n'
			print(info)
			view_window_st_data.insert(INSERT, info)
			con.commit()
		except Exception as e:
			showerror('Issue',e)
			con.rollback()
		finally:
			if con is not None:
				con.close()
			
	elif num == 6:
		update_window.deiconify()
		window.withdraw()
		update_window_ent_rno.delete(0,END)
		update_window_ent_name.delete(0,END)
		update_window_ent_marks.delete(0,END)
	elif num == 7:
		update_window.withdraw()
		window.deiconify()
	elif num == 8:	
		con = None
		try:
			con = connect("Tejas.db")
			cursor = con.cursor()
			sql = "update student set name = ?, marks= ? where rno = ? "
			rno = int(update_window_ent_rno.get())
			name = update_window_ent_name.get()
			marks = int(update_window_ent_marks.get())
			param = (name,marks,rno)
			cursor.execute(sql,param)
			 
				
			if  rno == "":
				showwarning('Wrong input','Roll No. should only be integers and Roll No. should not be empty')
				con.rollback()
				update_window_ent_rno.delete(0,END)
				update_window_ent_rno.focus()

			elif rno <= 0 or len(str(rno)) > 4 : 
				showwarning('Wrong input','Enter positive numbers only and length of rno should not be more than 4')
				con.rollback()
				update_window_ent_rno.delete(0,END)
				update_window_ent_rno.focus()
			
			elif name == "" :
				showwarning('Wrong input','Name should not be empty')
				con.rollback()
				update_window_ent_name.delete(0,END)
				update_window_ent_name.focus()  
			
			elif len(name) < 2 or name.isalpha() == False:
				showwarning('Wrong input','Name should only have alphabets and the length of name should not be less than 2')
				con.rollback()
				update_window_ent_name.delete(0,END)
				update_window_ent_name.focus()
				
			elif  marks == "" or marks < 0 or marks > 100:
				showwarning('Wrong input','Marks should be in the range of 0 to 100 and it should not be empty')
				con.rollback()
				update_window_ent_marks.delete(0,END)
				update_window_ent_marks.focus()

			
			else: 
				if cursor.rowcount > 0:		
					showinfo('GOOD NEWS',"Record Updated")
					con.commit()
					update_window_ent_rno.delete(0,END)
					update_window_ent_name.delete(0,END)
					update_window_ent_marks.delete(0,END)
					update_window_ent_rno.focus()
				else:
					showinfo('BE AWARE',"Record Does Not Exist")
					update_window_ent_rno.delete(0,END)
					update_window_ent_name.delete(0,END)
					update_window_ent_marks.delete(0,END)

		except ValueError:
			d = "Enter Integer Values"
			showwarning('Failure',d)
			update_window_ent_marks.delete(0,END)
			update_window_ent_rno.delete(0,END)
			con.rollback()
		
		except Exception as e:
			showerror('Issue',e)
			con.rollback()
		finally:
			if con is not None:
				con.close()
				

	elif num == 9:
		delete_window.deiconify()
		window.withdraw()
	
	elif num == 10:
		delete_window.withdraw()
		window.deiconify()
	
	elif num == 11:
		con = None
		try:
			con = connect("Tejas.db")
			cursor = con.cursor()
			sql = "delete from  student  where rno = ?"
			rno = delete_window_ent_rno.get()
			parameters = (rno,)
			cursor.execute(sql,parameters)
			if rno.isalpha() or rno == "":
				showwarning('Wrong input','Roll No. should only be integers and Roll No. should not be empty')
				con.rollback()
				update_window_ent_rno.delete(0,END)
				update_window_ent_rno.focus()
			
			elif rno <= str(0) or len(str(rno)) > 4 : 
				showwarning('Wrong input','Enter positive numbers only and length of rno should not be more than 4')
				con.rollback()
				update_window_ent_rno.delete(0,END)
				update_window_ent_rno.focus()	 
			

			else:
				if cursor.rowcount > 0:		
					con.commit()
					showinfo('AMAZING','Record Deleted')
					delete_window_ent_rno.focus()
				else:
					showinfo('BE AWARE','Record does not exist')
					delete_window_ent_rno.focus()
				delete_window_ent_rno.delete(0,END)
		except Exception as e:
			showerror('Issue',e)
			con.rollback()
		finally:
			if con is not None:
				con.close()
	
	elif num == 12:
		con = None
		try:
			con = connect('Tejas.db')
			cursor = con.cursor()
			def graph():
				cursor.execute("SELECT name , marks FROM student")
				data = cursor.fetchall()
				students = []
				scores = []
				for d in data:
					students.append(d[0])
					scores.append(d[1])

				plt.bar(students,scores,color = ['orange','powderblue', 'green'],)
				plt.xlabel("students")
				plt.ylabel("scores")
				plt.title('Results')
			
				plt.show()
				con.commit()
			graph()
		except Exception as e:
			showerror('Issue',e)
			
		finally:
			if con is not None:
				con.close()
	
		
	
try:
	wa = "https://ipinfo.io/"
	res = requests.get(wa)

	data = res.json()
	location = data['city']
except Exception as e:
	showerror('Issue',e)

try:
	a1 = "http://api.openweathermap.org/data/2.5/weather?units=metric"
	a2 = "&q=" + location
	a3 = "&appid=" + "43472b6fef09f80c2fb3d35b65e30308"
	web = a1 + a2 + a3
	resp = requests.get(web)
	help = resp.json()
	main = help["main"]
	temp = main["temp"]
except Exception as e:
	showerror("Issue", e)

try:
	webs = "https://www.brainyquote.com/quote_of_the_day"
	respo = requests.get(webs)
	datar = bs4.BeautifulSoup(respo.text, 'html.parser')
	info = datar.find('img',{'class':'p-qotd'})
	msg = info['alt']
	
except Exception as e:
	showerror("Issue", e)	




window = Tk()
window.title("S.M.S -Main Tap")
window.geometry("700x600+300+50")
window.configure(bg = 'orange')

s = Font(family = 'Tisa',size = 20,weight = 'bold',slant = 'roman')
btn_add = Button(window ,text = "ADD",activebackground = 'black',activeforeground = 'white',bd = 5,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(1))
btn_add.place(x=200,y=20,bordermode = OUTSIDE)
btn_view = Button(window ,text = "VIEW",activebackground = 'black',activeforeground = 'white',bd = 5,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(5))
btn_view.place(x=200,y=100 , bordermode = OUTSIDE)
btn_update = Button(window ,text = "UPDATE",activebackground = 'black',activeforeground = 'white',bd = 5,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(6))
btn_update.place(x=200,y=180,bordermode = OUTSIDE)
btn_delete = Button(window ,text = "DELETE",activebackground = 'black',activeforeground = 'white',bd = 5,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(9))
btn_delete.place(x=200,y=260,bordermode = OUTSIDE)
btn_charts = Button(window ,text = "CHARTS",activebackground = 'black',activeforeground = 'white',bd = 5,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(12))
btn_charts.place(x=200,y=340,bordermode = OUTSIDE)
location_lbl = Label(window , text = f"LOCATION : {location}", font = s,bg = 'orange',)
location_lbl.place(x =50,y = 430)
temperature = Label(window , text = f"Temperature: {temp}" + " " + u'\u2103', font = s,bg = 'orange',)
temperature.place(x =350,y = 430)
QOTD = Label(window , text = f"QOTD: {msg}", font = s,bg = 'orange',)
QOTD.place(x = 25,y = 480)

add_window = Toplevel(window )
add_window.title("Add Tap.")
add_window.geometry("700x600+300+50")
add_window.configure(bg = 'orange')

add_window_lbl_rno = Label(add_window, text = "Enter R.No", font = s,bg = 'orange')
add_window_ent_rno = Entry(add_window, bd = 4,font = s,cursor = 'watch',)
add_window_lbl_name = Label(add_window, text = "Enter Name", font = s,bg = 'orange')
add_window_ent_name = Entry(add_window, bd = 4,font = s,cursor = 'watch')
add_window_lbl_marks = Label(add_window, text = "Enter Marks", font = s,bg = 'orange')
add_window_ent_marks = Entry(add_window, bd = 4,font = s,cursor = 'watch')
add_window_save = Button(add_window,text = "Save",activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(3))
add_window_back = Button(add_window,text = "Back",activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(2))

add_window_ent_rno.focus()
add_window_lbl_rno.place(x = 200,y = 20)
add_window_ent_rno.place(x = 200,y = 65)
add_window_lbl_name.place(x = 200,y = 110)
add_window_ent_name.place(x = 200,y = 155)
add_window_lbl_marks.place(x = 200,y = 200)
add_window_ent_marks.place(x = 200,y = 245)

add_window_save.place(x = 200,y = 310,bordermode = OUTSIDE)
add_window_back.place(x = 200,y = 390,bordermode = OUTSIDE)
add_window.withdraw()

view_window = Toplevel(window )
view_window.title("View Tap")
view_window.geometry("700x600+300+50")
view_window.configure(bg = 'orange')

view_window_st_data = ScrolledText(view_window,width = 40,height = 15,font = s)
view_window_btn_back = Button(view_window,text = "Back" , activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s, justify = 'center',relief = GROOVE,command = lambda:f(4))
view_window_st_data.place(x = 10,y = 10)
view_window_btn_back.place(x = 200,y = 400 ,bordermode = OUTSIDE)
view_window.withdraw()

update_window = Toplevel(window )
update_window.title("Update Tap.")
update_window.geometry("700x600+300+50")
update_window.configure(bg = 'orange')

update_window_lbl_rno = Label(update_window, text = "Enter R.No", font = s,bg = 'orange')
update_window_ent_rno = Entry(update_window, bd = 5,font = s,cursor = 'watch')
update_window_lbl_name = Label(update_window, text = "Enter Name", font = s,bg = 'orange')
update_window_ent_name = Entry(update_window, bd = 5,font = s,cursor = 'watch')
update_window_lbl_marks = Label(update_window, text = "Enter Marks", font = s,bg = 'orange')
update_window_ent_marks = Entry(update_window, bd = 5,font = s,cursor = 'watch')
update_window_save = Button(update_window,text = "Update",activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(8))
update_window_back = Button(update_window,text = "Back",activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(7))

update_window_ent_rno.focus()
update_window_lbl_rno.place(x = 200,y = 20)
update_window_ent_rno.place(x = 200,y = 65)
update_window_lbl_name.place(x = 200,y = 110)
update_window_ent_name.place(x = 200,y = 155)
update_window_lbl_marks.place(x = 200,y = 200)
update_window_ent_marks.place(x = 200,y = 245)
update_window_save.place(x = 200,y = 310,bordermode = OUTSIDE)
update_window_back.place(x = 200,y = 390,bordermode = OUTSIDE)
update_window.withdraw()

delete_window = Toplevel(window )
delete_window.title("Delete Tap.")
delete_window.geometry("700x600+300+50")
delete_window.configure(bg = 'orange')


delete_window_lbl_rno = Label(delete_window, text = "Enter R.No", font = s,bg = 'orange')
delete_window_ent_rno = Entry(delete_window, bd = 4,font = s,cursor = 'watch')
delete_window_ent_rno.focus()
delete_window_lbl_rno.place(x = 200,y = 20)
delete_window_ent_rno.place(x = 200,y = 65)
delete_window_del = Button(delete_window,text = "Delete",activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(11))
delete_window_back = Button(delete_window,text = "Back",activebackground = 'black',activeforeground = 'white',bd = 4,width = 15,font = s,justify = 'center',relief = GROOVE,command = lambda:f(10))
delete_window_del.place(x = 200,y = 310,bordermode = OUTSIDE)
delete_window_back.place(x = 200,y = 390,bordermode = OUTSIDE)
delete_window.withdraw()


window .mainloop()